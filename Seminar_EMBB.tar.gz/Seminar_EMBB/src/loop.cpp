#include <iostream>

int main() {
	for (unsigned int i = 0; i < 10; ++i) {
		std::cout << "i = " << i << std::endl;
	}
}
